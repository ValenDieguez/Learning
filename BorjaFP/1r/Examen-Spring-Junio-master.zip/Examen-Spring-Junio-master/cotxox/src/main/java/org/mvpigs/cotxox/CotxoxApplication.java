package org.mvpigs.cotxox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CotxoxApplication {

	public static void main(String[] args) {
		SpringApplication.run(CotxoxApplication.class, args);
	}
}
