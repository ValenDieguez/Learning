package org.mvpigs.cotxox.service;

import org.mvpigs.cotxox.domain.Conductor;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
@Service
public class ConductorService extends Conductor {

    @PersistenceContext
    private EntityManager em;

    public Conductor recuperarConductor(String tarjeta){
        Conductor nobatillo=em.find(Conductor.class, tarjeta);
        return nobatillo;
    }

    public void init(){
        Conductor Sabrina = new Conductor();
        Conductor Cici = new Conductor();
        Sabrina.setNombre("Sabrina");
        Cici.setNombre("Cici");
        Sabrina.setMatricula("5DHJ444");
        Cici.setMatricula("7JKK555");
        Sabrina.setModelo("Toyota Prius");
        Cici.setModelo("Mercedes A");
        Sabrina.setOcupado(false);
        Cici.setOcupado(false);

        em.persist(Sabrina);
        em.persist(Cici);
    }
}
