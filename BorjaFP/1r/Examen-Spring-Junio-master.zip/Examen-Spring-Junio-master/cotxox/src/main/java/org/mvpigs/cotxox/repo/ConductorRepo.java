package org.mvpigs.cotxox.repo;

import org.aspectj.apache.bcel.Repository;
import org.mvpigs.cotxox.domain.Conductor;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@org.springframework.stereotype.Repository
public class ConductorRepo extends Repository{


    @PersistenceContext
    private EntityManager em;

   public List<Conductor> findByOcupado(int isOcupado){

       }



   }

