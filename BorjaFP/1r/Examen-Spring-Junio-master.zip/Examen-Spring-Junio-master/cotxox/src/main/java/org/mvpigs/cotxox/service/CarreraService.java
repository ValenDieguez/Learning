package org.mvpigs.cotxox.service;

import org.mvpigs.cotxox.domain.Carrera;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Service
public class CarreraService {

    @PersistenceContext
    private EntityManager em;

    public Long crearCarrera(String tarjetaCredito, String origen, String destino, int distancia,int costeTotal ){
        Carrera carrera = new Carrera(tarjetaCredito);
        carrera.setOrigen(origen);
        carrera.setDestino(destino);
        carrera.setDistancia(distancia);
        carrera.setCosteTotal(costeTotal);
        em.persist(carrera);
         return carrera.getId();
}

    public Carrera recuperaCarrera(long id){
        Carrera carrera= em.find(Carrera.class ,id );
        return carrera;
    }


}


