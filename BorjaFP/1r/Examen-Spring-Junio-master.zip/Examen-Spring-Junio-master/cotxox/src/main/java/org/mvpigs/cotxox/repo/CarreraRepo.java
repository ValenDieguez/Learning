package org.mvpigs.cotxox.repo;

import org.aspectj.apache.bcel.Repository;


@org.springframework.stereotype.Repository
public class CarreraRepo extends Repository {
}
