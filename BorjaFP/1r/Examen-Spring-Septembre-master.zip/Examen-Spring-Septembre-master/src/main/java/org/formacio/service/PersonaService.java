package org.formacio.service;

import org.formacio.domain.Persona;
import org.formacio.repositori.PersonaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Optional;

@Service
@Transactional
public class PersonaService {

    @Autowired
    private PersonaRepository repositori;

    public Optional<Persona> carrega(long codi) {
        Optional<Persona> persona = repositori.findById(codi);
        persona.ifPresent(p -> p.getMascotes().size());
        return persona;
    }

}
