package org.mvpigs;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RomanNumberLogic {
    String regex = null;
    String testRegex = "M";


    Pattern p = Pattern.compile(regex);
    Matcher matcher = p.matcher(testRegex);

    public int transformer(char romanNumber) {
        if (romanNumber == 'M') {
            return 1000;
        }
        return 1000;
    }

    public void finder() {
        if (matcher.find()) {
            String foundString= matcher.group();

        }
    }
}
}


