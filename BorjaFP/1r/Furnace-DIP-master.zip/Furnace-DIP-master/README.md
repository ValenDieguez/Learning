Furnace-DIP
