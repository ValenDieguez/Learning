package org.mvpigs;

public class Electonico implements Termometro {

    /**
     * Simula el termostato de un horno
     *
     * @return lectura de temperatura
     */
    public double read(Heat temp) {

        System.out.println(temp.getFinalTemp());
        return temp.getFinalTemp();
    }

    private double tempCalculator() {

        double randomNum = Math.random() * 20;
        double actualTemp = 10 - randomNum;
        return actualTemp;
    }

}
