package org.mvpigs;

public class Mercurio implements Termometro {
    /**
     * Simula termoestato exterior
     *
     * @return la temperatura de fuera
     */
    public double read(Heat heat) {

        System.out.println(heat.getFinalTemp());
        return heat.getFinalTemp();

    }

    /**
     * esto es un simple addon para hacerlo mas real
     *
     * @param estacion las 4 estaciones de vivaldi en castellano ( sino te devuelve una random)
     * @return un double que representa la temperatura
     */
    public double read(String estacion) {
        Heat temp = new Heat(tempCalculator(estacion));
        System.out.println(temp.getFinalTemp());
        return temp.getFinalTemp();

    }

    private double tempCalculator() {
        double temperature = Math.random() * 25;
        return temperature;
    }

    private double tempCalculator(String estacion) {
        double temperature = 0;
        if (estacion.equals("primavera")) {
            temperature = Math.random() * 18 + 10;
        } else if (estacion.equals("verano")) {
            temperature = Math.random() * 10 + 23;
        } else if (estacion.equals("otoño")) {
            temperature = Math.random() * 18 + 10;
        } else if (estacion.equals("invierno")) {
            temperature = Math.random() * 15 + 3;
        } else {
            temperature = tempCalculator();
        }
        return temperature;
    }
}
