package org.mvpigs;

public interface Regulate {

}
