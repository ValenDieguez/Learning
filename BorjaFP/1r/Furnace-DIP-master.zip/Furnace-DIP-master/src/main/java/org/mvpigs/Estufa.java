package org.mvpigs;

public class Estufa implements Heather {
    double heat = 0;

    public double engage(double setTemperature) {
        heat = setTemperature / 10;
        return heat;
    }

    public double disengage() {
        heat = 0;
        return heat;
    }

    public double getHeat() {
        return heat;
    }
}
