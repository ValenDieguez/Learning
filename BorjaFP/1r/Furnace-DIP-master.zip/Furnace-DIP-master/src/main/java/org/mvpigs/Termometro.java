package org.mvpigs;

public interface Termometro extends Regulate {

    /**
     * read the temperature
     */
    public double read(Heat heat);
}
