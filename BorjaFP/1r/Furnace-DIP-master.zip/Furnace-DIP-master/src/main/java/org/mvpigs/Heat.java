package org.mvpigs;

public class Heat {

    private double temperature;
    private double finalTemp;

    public Heat(double temperature) {
        this.temperature = temperature;
    }

    public double regulateTemperature(double heat) {
        if (heat > 0) {
            finalTemp = finalTemp + (heat / 10);
            System.out.println(finalTemp);
            return finalTemp;
        }
        if (heat <= 0) {
            while (finalTemp >= temperature) {
                finalTemp = finalTemp - 5;
                return finalTemp;
            }
        }
        return finalTemp;
    }

    public double getTemperature() {
        return temperature;
    }

    public double getFinalTemp() {
        return finalTemp;
    }

}
