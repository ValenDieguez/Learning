package org.mvpigs;

public interface Heather extends Regulate {

    /**
     * Turn on the Heather
     */
    public double engage(double setHeat);


    /**
     * turn off the Heather
     */
    public double disengage();
    public double getHeat();
}
