package org.mvpigs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
        String line;
        boolean open= true;
        double setTemp=150;
        int vuelta= 0;
        int setSeconds=500;
        Termometro termometroMercurio = new Mercurio();
        Heather estufita = new Estufa();
        Heat heat = new Heat(setTemp);
        System.out.println("Welcome to Lanistae Shop Manager: Please use -sh to choose between shops-");
        Cli cli = new Cli();
        do {
            line = buf.readLine();
            cli.parse(new String[]{line});

        } while (line != null && !"exit".equals(line));
    }


        while ( open == true){

            if (setTemp>termometroMercurio.read(heat)){
                heat.regulateTemperature(estufita.engage(setTemp));
                vuelta=vuelta+1;
                System.out.println(termometroMercurio.read(heat));
            }
            else if(vuelta < setSeconds){
                heat.regulateTemperature(estufita.engage(0));
                vuelta=vuelta+1;
                System.out.println(termometroMercurio.read(heat));
            }
            else{open =false;}


        }
    }BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
    String line;

        System.out.println("Welcome to Lanistae Shop Manager: Please use -sh to choose between shops-");
    Cli cli = new Cli();
        do {
        line = buf.readLine();
        cli.parse(new String[]{line});

    } while (line != null && !"exit".equals(line));
}


}

        }
