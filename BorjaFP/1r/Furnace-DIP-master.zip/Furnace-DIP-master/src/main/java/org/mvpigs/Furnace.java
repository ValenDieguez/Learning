package org.mvpigs;

public class Furnace implements Heather {
    private double heat = 0;

    public double engage(double setTemperature) {
        heat = setTemperature / 5;
        return heat;
    }


    public double disengage() {
        heat = 0;
        return heat;
    }

    public double getHeat() {
        return heat;
    }
}
