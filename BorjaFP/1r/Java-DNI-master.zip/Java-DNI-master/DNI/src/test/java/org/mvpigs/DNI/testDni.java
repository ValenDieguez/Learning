package org.mvpigs.DNI;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class TestDni 
    extends TestCase
{
    public TestDni( String testName )
    {
        super( testName );
    }

    public static Test suite()
    {
        return new TestSuite( TestDni.class );
    }

    Tabla tabla = new Tabla();

    public void testDniIsValid() {
        Dni dni = new Dni("41571603T");
        Boolean isDniValid = tabla.isDniValid(dni);
        assertTrue(isDniValid);
    }

    public void testDniIsNotValid() {
        Dni dni = new Dni("12345678A");
        Boolean isDniValid = tabla.isDniValid(dni);
        assertFalse(isDniValid);
    }
    

}
