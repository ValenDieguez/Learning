package org.mvpigs.DNI;

public class Dni{
    private int number;
    private char letter;
    private String identifier;

    public Dni(String dni){
        this.identifier = dni;
        int letterIndex = dni.length() - 1;
        this.letter = dni.charAt(letterIndex);
        this.number = Integer.parseInt(dni.substring(0, letterIndex));
    }

    public String getIdentifier(){
        return this.identifier;
    }

    public int getNumber(){
        return this.number;
    }

    public char getLetter(){
        return this.letter;
    }
} 