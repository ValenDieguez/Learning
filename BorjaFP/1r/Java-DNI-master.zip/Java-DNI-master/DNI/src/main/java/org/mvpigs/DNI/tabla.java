package org.mvpigs.DNI;

public class Tabla {
    private char[] tabla = { 'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V',
            'H', 'L', 'C', 'K', 'E' };
    
    public Tabla() {}

    public Boolean isDniValid(Dni dni){
        int letterIndex = calculateTableLetter(dni.getNumber());
        char letterAssigned = calculateLetterAssigned(letterIndex);
        if (dni.getLetter() == letterAssigned){
            return true;
        } else {
            return false;
        }
    }

    private int calculateTableLetter(int number){
        return number % 23;
    }

    private char calculateLetterAssigned(int letterIndex) {
        return tabla[letterIndex];
    }

}