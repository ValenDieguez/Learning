package org.mvpigs.DNI;
import java.util.ArrayList;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Tabla tabla = new Tabla();
        ArrayList<Dni> dnis = new ArrayList<Dni>();
        dnis.add(new Dni("41537901Q"));
        dnis.add(new Dni("41571603T"));
        dnis.add(new Dni("12345678A"));

        for (Dni dni : dnis) {
            System.out.println(tabla.isDniValid((dni)));
        }
    }
}
