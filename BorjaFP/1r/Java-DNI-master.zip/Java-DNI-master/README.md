Java-DNI
