package arteco.valen.springFirstTry;

class IncorrectQuantityException extends Exception {

    IncorrectQuantityException(String message) {
        super(message);
    }
}
