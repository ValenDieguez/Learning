package arteco.valen.shop;

public enum Role {
    USER,MANAGER
}
