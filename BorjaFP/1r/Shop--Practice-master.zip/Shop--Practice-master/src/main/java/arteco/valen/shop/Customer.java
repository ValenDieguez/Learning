package arteco.valen.shop;

interface Customer extends Person {



}