package arteco.valen.shop;

interface Manager extends Person {


}