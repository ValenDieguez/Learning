package arteco.valen.shop.exception;

public class IncorrectPermissionException extends Exception {

   public IncorrectPermissionException(String message) {
        super(message);
    }


}
