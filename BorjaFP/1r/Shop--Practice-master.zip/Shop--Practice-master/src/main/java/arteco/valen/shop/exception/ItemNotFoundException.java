package arteco.valen.shop.exception;

public class ItemNotFoundException extends Exception{

    public ItemNotFoundException(String message) {
        super(message);
    }

}
