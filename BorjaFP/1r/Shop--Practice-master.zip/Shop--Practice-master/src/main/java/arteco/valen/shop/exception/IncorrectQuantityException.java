package arteco.valen.shop.exception;

public class IncorrectQuantityException extends Exception {

    public IncorrectQuantityException(String message) {
        super(message);
    }
}
