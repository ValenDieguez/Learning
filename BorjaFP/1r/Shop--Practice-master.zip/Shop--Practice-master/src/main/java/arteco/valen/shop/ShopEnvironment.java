package arteco.valen.shop;

public interface ShopEnvironment {
    Shop getShop();
}
