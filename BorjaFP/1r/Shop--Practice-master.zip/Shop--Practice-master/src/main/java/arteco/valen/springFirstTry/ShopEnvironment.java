package arteco.valen.springFirstTry;

public interface ShopEnvironment {
    Shop getShop();
}
