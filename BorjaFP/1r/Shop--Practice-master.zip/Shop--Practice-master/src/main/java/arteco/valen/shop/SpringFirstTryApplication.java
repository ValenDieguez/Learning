package arteco.valen.shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFirstTryApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringFirstTryApplication.class, args);
    }


}
