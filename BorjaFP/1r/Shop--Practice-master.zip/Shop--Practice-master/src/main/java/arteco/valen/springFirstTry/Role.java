package arteco.valen.springFirstTry;

public enum Role {
    USER,MANAGER
}
