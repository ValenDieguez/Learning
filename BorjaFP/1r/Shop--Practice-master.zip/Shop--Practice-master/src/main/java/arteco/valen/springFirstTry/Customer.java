package arteco.valen.springFirstTry;

public interface Customer extends Person {



}