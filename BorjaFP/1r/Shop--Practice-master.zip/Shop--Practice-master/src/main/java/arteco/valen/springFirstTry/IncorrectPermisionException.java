package arteco.valen.springFirstTry;

class IncorrectPermisionException extends Exception {

    IncorrectPermisionException(String message) {
        super(message);
    }


}
