package arteco.valen.springFirstTry;

class ItemNotFoundException extends Exception{

    ItemNotFoundException(String message) {
        super(message);
    }

}
