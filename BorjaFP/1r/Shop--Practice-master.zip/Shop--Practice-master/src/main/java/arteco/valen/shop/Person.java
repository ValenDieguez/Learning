package arteco.valen.shop;

public interface Person {

  String getName() ;

  int getYears();

  Role getRole();
}
