package arteco.valen.springFirstTry;

interface Manager extends Person {


}