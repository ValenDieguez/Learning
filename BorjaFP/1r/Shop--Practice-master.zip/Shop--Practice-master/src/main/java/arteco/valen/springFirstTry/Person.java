package arteco.valen.springFirstTry;

public interface Person {

  String getName() ;

  int getYears();

  Role getRole();
}
