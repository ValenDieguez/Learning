package arteco.valen.springFirstTry;

import static org.junit.Assert.*;

public class TiendaTest {

}