package org.mvpigs;

import java.util.ArrayList;
import java.util.stream.IntStream;

public class Ejercicios implements CharSequence {
    private String frase;
    ArrayList<Integer> indexes= new ArrayList<>();


    public int length() {
        return 0;
    }

    public char charAt(int index) {
        return 0;
    }

    public CharSequence subSequence(int start, int end) {
        return null;
    }

    public IntStream chars() {
        return null;
    }

    public IntStream codePoints() {
        return null;
    }

    public Ejercicios(String frase) {
        this.frase=frase;
    }

    public void transforms(String frase){

        for(int i=0;i< frase.length();i++);
        ;
        String palabra=frase.charAt();
    }

}

