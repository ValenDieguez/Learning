package org.mvpigs;

interface somethingWrong {
    void aMethod(int aValue);
    System.out.PrintLn("moreno")
}