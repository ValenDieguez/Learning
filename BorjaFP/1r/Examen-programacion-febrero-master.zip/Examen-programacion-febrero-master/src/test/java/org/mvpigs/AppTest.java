package org.mvpigs;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    Wallet wallet_1= new Wallet();
    Wallet wallet_2= new Wallet();
    Transaction trx =  new Transaction("hash_1", "0", wallet_1.getAddress(), wallet_2.getAddress(), 20, "a flying pig!");
    Wallet origin = new Wallet();
    BlockChain bChain = new BlockChain();




    public AppTest( String testName )
    {
        super( testName );

    }


    public static Test suite()
    {
        return new TestSuite( AppTest.class );

    }


    public void testWallet(){


        wallet_1.generateKeyPair();
        System.out.println(wallet_1.Address);
        System.out.println(wallet_1.sKey);
        System.out.println("\n Direccion de la Wallet_1: \n" +  wallet_1.getAddress().hashCode());

    }
    public void testWallet2(){
        wallet_2.generateKeyPair();
        System.out.println(wallet_2.Address);
        System.out.println(wallet_2.sKey);
        System.out.println("\n Direccion de la Wallet_2: \n" +  wallet_2.getAddress().hashCode());
    }

    public void testver2Wallets(){
        System.out.println("Wallet_1: \n" + wallet_1.toString());
        System.out.println("Wallet_2: \n" + wallet_2.toString());
    }

    public void testTransaccion(){

        System.out.println("\n" + "Ver transaccion" + "\n" +
                "==============="        );

        System.out.println(trx.toString());
    }

    public void testBlockChain() {


        System.out.println("\n" + "Ver BlockChain" + "\n" +
                "==============");
        origin.generateKeyPair();
        Transaction trx = new Transaction("hash_1", "0", origin.getAddress(), wallet_1.getAddress(), 20, "bacon eggs");
        bChain.addOrigin(trx);
        Transaction trx1 = new Transaction("hash_2", "1", origin.getAddress(), wallet_2.getAddress(), 10, "spam spam spam");
        bChain.addOrigin(trx1);
        Transaction trx2 = new Transaction("hash_3", "hash_1", wallet_1.getAddress(), wallet_2.getAddress(), 20, "a flying pig!");
        bChain.addOrigin(trx2);
        bChain.summarize();

    }
        public void testSelectIndexBlock() {
            Integer position = 1;
            System.out.println("\n" + "Ver Transaccion en posicion " + position.toString() + " del BlockChain" + "\n" +
                    "============================================");
            origin.generateKeyPair();
            Transaction trx = new Transaction("hash_1", "0", origin.getAddress(), wallet_1.getAddress(), 20, "bacon eggs");

            Transaction trx1 = new Transaction("hash_2", "1", origin.getAddress(), wallet_2.getAddress(), 10, "spam spam spam");

            Transaction trx2 = new Transaction("hash_3", "hash_1", wallet_1.getAddress(), wallet_2.getAddress(), 20, "a flying pig!");

            bChain.addOrigin(trx);

            bChain.addOrigin(trx1);

            bChain.addOrigin(trx2);

            bChain.summarize(position);
        }


        public void testAddPigcoins(){
            Transaction trx = new Transaction("hash_1", "0", origin.getAddress(), wallet_1.getAddress(), 20, "bacon eggs");

            Transaction trx1 = new Transaction("hash_2", "1", origin.getAddress(), wallet_2.getAddress(), 10, "spam spam spam");

            Transaction trx2 = new Transaction("hash_3", "hash_1", wallet_1.getAddress(), wallet_2.getAddress(), 20, "a flying pig!");
            bChain.addOrigin(trx);

            bChain.addOrigin(trx1);

            bChain.addOrigin(trx2);

            System.out.println("\n" + "Ver el total de pigcoins de las dos wallet" + "\n" +
                    "=========================================="        );

            wallet_1.loadCoins(bChain);
            System.out.println(wallet_1.toString());

            wallet_2.loadCoins(bChain);
            System.out.println(wallet_2.toString());
        }
}
