package org.mvpigs;

import java.util.ArrayList;

import java.security.PublicKey;
public class Transaction {

    String hash= null;
    String prev_hash=null;
    PublicKey pKey_sender=null;
    PublicKey pKey_recipient=null;
    int pigcoins=0;
    String message= null;
    byte[] signature=new byte[8];

    public Transaction(String hash, String prev_hash, PublicKey pKey_sender, PublicKey pKey_recipient, int pigcoins, String message){
        this.hash = hash;
        this.prev_hash = prev_hash;
        this.pKey_sender = pKey_sender;
        this.pKey_recipient = pKey_recipient;
        this.pigcoins = pigcoins;
        this.message=message;

    }
    public String getHash() {
        return hash;
    }

    public String getPrev_hash() {
        return prev_hash;
    }

    public PublicKey getpKey_sender() {
        return pKey_sender;
    }

    public PublicKey getpKey_recipient() {
        return pKey_recipient;
    }

    public int getPigcoins() {
        return pigcoins;
    }

    public String getMessage() {
        return message;
    }

    public byte[] getSignature() {
        return signature;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public void setPrev_hash(String prev_hash) {
        this.prev_hash = prev_hash;
    }

    public void setpKey_sender(PublicKey pKey_sender) {
        this.pKey_sender = pKey_sender;
    }

    public void setpKey_recipient(PublicKey pKey_recipient) {
        this.pKey_recipient = pKey_recipient;
    }

    public void setPigcoins(int pigcoins) {
        this.pigcoins = pigcoins;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setSignature(byte[] signature) {
        this.signature = signature;
    }
}
