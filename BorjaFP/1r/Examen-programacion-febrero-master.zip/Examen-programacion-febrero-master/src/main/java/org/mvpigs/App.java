package org.mvpigs;

import org.mvpigs.Wallet;

import java.security.KeyPair;
import java.util.Map;

public class App {

    public static void main( String[] args ) {



    }}