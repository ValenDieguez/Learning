package org.mvpigs;

import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class Wallet {

    PublicKey Address = null;
    PrivateKey sKey = null;
    int total_input = 0;
    int total_output = 0;
    int balance = 0;
    Transaction inputTransactions = null;
    Transaction outputTransactions = null;
    KeyPair pair = null;
    BlockChain blockChain = null;

    public Wallet() {

    }

    public void generateKeyPair() {
        KeyPair pair = GenSig.generateKeyPair();
        setSK(pair.getPrivate());
        setAddress(pair.getPublic());

    }

    private void setAddress(PublicKey pKey) {
        this.Address = pKey;
    }

    private void setSK(PrivateKey sKey) {
        this.sKey = sKey;

    }

    public PublicKey getAddress() {
        return this.Address;
    }

    private PrivateKey getSKey() {
        return this.sKey;

    }

    public int loadCoins(BlockChain blockChain) {
        for (int i = 1; i <= blockChain.getBlockChanceSize(); i++) {
            Transaction transaction = blockChain.getTransaction(i);
            int coins = transaction.getPigcoins()+total_input;
            System.out.println(coins);
            return total_input=coins;}
            System.out.println(total_input);

        return total_input;
    }







    /*private void loadInputTransactions(bChain){


    }

    private void loadOutputTransactions(bChain) {


    }*/


}

