package org.mvpigs;

import java.security.PublicKey;
import java.util.HashMap;
import java.util.Map;

public class BlockChain {
int contador=1;


    Map<Integer,Transaction> blockChain= new HashMap<Integer,Transaction>();

    public int addOrigin(Transaction transaction){

        blockChain.put(contador,transaction);
        return contador++;

    }

    public void processTransactions(Transaction pKey_sender,Transaction pKey_recipient,Transaction consumedCoins, Transaction message,Transaction signedTransaction){


    }

    public void isConsumedCoinValid(Transaction consumedCoins){


    }

    public void isSignatureValid(Transaction pKey_sender, Transaction message, Transaction signedTransaction){

    }

    public void createTransaction(Transaction pKey_sender, Transaction pKey_recipient, Transaction consumedCoins, Transaction message, Transaction signedTransaction){

    }
    public void loadInputTransactions(PublicKey address){

    }
    public void loadOutputTransactions(PublicKey address){

    }
    public void loadWallet(PublicKey address){

    }
    public void summarize() {
        for (int i = 1; i <= blockChain.size(); i++) {
            int identificador = blockChain.get(i).hashCode();
            System.out.println(identificador);
        }
    }

    public void summarize(int posicion){
        int identificador = blockChain.get(posicion).hashCode();
        System.out.println(identificador);

            }
    public int getBlockChanceSize(){
        int size=blockChain.size();
        return size;

    }

    public Transaction getTransaction(int posicion){
        Transaction transactaion=blockChain.get(posicion);
        return transactaion;
    }
    }





