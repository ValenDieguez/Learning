#http://adventofcode.com/2017/day/2/input


def checksum(list):
    majornumber = list[0]
    minornumber = list[0]
    for index in range(0,len(list)):
        current= list[index]
        if current >= majornumber:
            majornumber=current
        elif current <= minornumber:
            minornumber = current
    sumNumber= majornumber-minornumber
    return sumNumber





