x=1243545
num=1
[int(x) for x in str(num)]