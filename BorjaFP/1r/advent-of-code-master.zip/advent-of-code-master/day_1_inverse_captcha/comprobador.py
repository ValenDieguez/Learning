

def comprobador(stringNum):
    if stringNum[0]==stringNum[-1]:
        return int(stringNum[-1])
    else:
        return 0

