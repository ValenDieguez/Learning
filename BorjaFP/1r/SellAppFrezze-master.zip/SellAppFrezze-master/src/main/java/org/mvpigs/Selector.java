//<<<<<<< Updated upstream
/*package org.mvpigs;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import java.sql.ResultSet;


=======
package org.mvpigs;

import java.sql.
>>>>>>> Stashed changes
public class Selector {

private Connection connect = null;
private String serverURL = "jdbc:mysql://localhost:3306/MyFirstConnection";
private Connection  connected = DriverManager.getConnection(serverURL,"root","1234");
private Statement stmt = null;
private ResultSet rs = null;

public void exemptionCatcher() {
    try {
        stmt = connect.createStatement();
        rs = stmt.executeQuery("SELECT foo FROM bar");

        // or alternatively, if you don't know ahead of time that
        // the query will be a SELECT...

        if (stmt.execute("SELECT foo FROM bar")) {
            rs = stmt.getResultSet();
        }

        // Now do something with the ResultSet ....
    } catch (SQLException ex) {
        // handle any errors
        System.out.println("SQLException: " + ex.getMessage());
        System.out.println("SQLState: " + ex.getSQLState());
        System.out.println("VendorError: " + ex.getErrorCode());
    } finally

    {
        // it is a good idea to release
        // resources in a finally{} block
        // in reverse-order of their creation
        // if they are no-longer needed

        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException sqlEx) {
            } // ignore

            rs = null;
        }

        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException sqlEx) {
            } // ignore

            stmt = null;
        }
    }
}
    public Selector() throws SQLException {
    }


    public void showProducts() throws SQLException {
        System.out.Println(connect.prepareStatement("SELECT Name FROM Products"));

    }
    public  Product  createProduct(int id) throws SQLException {
        String name=toString(connect.prepareStatement("SELECT Name FROM Products"));
        double price=connect.prepareStatement("SELECT Name FROM Products");

    Product product= new Product(id,name,price);

    return product;
  }

    public Vendedor createVendedor(int id) throws SQLException {

        String name = toString(connect.prepareStatement("SELECT Name FROM vendedor where idVendedor== id"));
        Vendedor vendedor= new Vendedor(id,name);

        return vendedor;
    }

    public Cliente createCliente(int id) throws SQLException {

        String name = toString(connect.prepareStatement("SELECT Name FROM Products"));
        String direccion = connect.prepareStatement("SELECT Name FROM Products");
        Cliente cliente= new Cliente(id,name,direccion);

        return cliente;
    }

    public void addFactura(int vendedor,int cliente, double totalPrice){

    }
}*/
