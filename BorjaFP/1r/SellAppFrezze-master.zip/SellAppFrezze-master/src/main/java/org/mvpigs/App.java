package org.mvpigs;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Hello world!
 *
 */
public class App {
        public static void main(String[] args) throws SQLException {

        String query = "Select * from vendedor";
        ResultSet rs = org.mvpigs.MySQL.dbConnection.executeQueryRS(query);
        mostrarvendedor();
        showProducts();

    }

    private static void mostrarvendedor() throws SQLException {
        String query = "Select * from vendedor";
        ResultSet rs = org.mvpigs.MySQL.dbConnection.executeQueryRS(query);
        while (rs.next()) {
            System.out.println("ID Vendedor: " + rs.getString("idVendedor"));
            System.out.println("Nombre: " + rs.getString("name"));

        }

}

    public static void showProducts() throws SQLException {
        String query = "Select * from Productos";
        ResultSet rs = org.mvpigs.MySQL.dbConnection.executeQueryRS(query);
        while (rs.next()) {
            System.out.println("ID productos: " + rs.getString("idProducto"));
            System.out.println("Nombre: " + rs.getString("NameProduct"));
            System.out.println("Precio: " + rs.getString("Price"));

        }

   /* private static void factura(){
            Cliente cliente = ;
            Product producto= createProduct();
            Vendedor vendedor = CreateVendedor();

            Vendedor crearFactura(cliente,vendedor,producto)
        }*/





}}