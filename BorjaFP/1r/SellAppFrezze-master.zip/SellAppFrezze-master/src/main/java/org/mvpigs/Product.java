package org.mvpigs;

import java.util.ArrayList;
import java.util.List;

public class Product {
    private int idProduct=0;
    private String nameProduct=null;
    private double priceProduct=0;
    private double totalPrice=0;
    private List productos= new ArrayList();


    public Product(int idProduct,String nameProduct, double priceProduct){

        this.idProduct=idProduct;
        this.nameProduct=nameProduct;
        this.priceProduct=priceProduct;
    }


    public double getPriceProduct() {
        return this.priceProduct;
    }

    public int getIdProduct() {
        return this.idProduct;
    }

    public String getNameProduct() {
        return this.nameProduct;
    }

    public double getTotalPrice() {
        return this.totalPrice;
    }

    public List getProductos() {
        return productos;
    }

    public void setTotalPrice(double reset) {
        totalPrice = reset;
    }

    /*public void setProductos(List productos) {
        productos = /*vull posar una llista buida[];}*/


    public double totalPrice(double priceProduct){
        totalPrice=totalPrice + priceProduct;
        return totalPrice;
    }

    public void addProduct(Product product){
        productos.add(product);

    }
    public void seleccionarProducto(Product product){
         addProduct(product);
        totalPrice(product.getPriceProduct());

    }

}
