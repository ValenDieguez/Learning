package org.mvpigs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Vendedor {
    private int idVendedor = 0;
    private String nameVendedor = null;
    private Vendedor vendedor = null;
    private Product producto = null;
    private Cliente cliente = null;


    public Vendedor(int idVendedor, String nameVendedor) {
        this.idVendedor = idVendedor;
        this.nameVendedor = nameVendedor;
    }


    public int getIdVendedor() {
        return this.idVendedor;
    }

    public String getNameVendedor() {
        return this.nameVendedor;
    }

    public static Product createProduct(int id) throws SQLException {
        String query1 = "Select * from Productos Where idProducto =" + id;
        ResultSet rs1 = org.mvpigs.MySQL.dbConnection.executeQueryRS(query1);
        while (rs1.next()) {

            String Name = null;
            try {
                Name = rs1.getString("NameProduct");
            } catch (SQLException e) {
                e.printStackTrace();
            }
            String price = rs1.getString("Price");}

            String Name=rs1.getString("NameProduct");
            String price=rs1.getString("Price");
            double precio = Double.parseDouble(price);
            Product producto = new Product(id, Name, precio);

            return producto;

    }

    public static Vendedor createVendedor(int id) throws SQLException {
        String query1 = "Select * from vendedor Where idVendedor =" + id;
        ResultSet rs1 = org.mvpigs.MySQL.dbConnection.executeQueryRS(query1);
        while (rs1.next()) {

            String Name = null;
            try {
                Name = rs1.getString("Name");
            } catch (SQLException e) {
                e.printStackTrace();
            }}
            String Name = rs1.getString("Name");
            Vendedor vendedor = new Vendedor(id, Name);

        return vendedor;

    }


    public  Cliente createCliente(int id) throws SQLException {
            String query2 = "Select * from cliente Where idCliente =" + id;
            ResultSet rs2 = org.mvpigs.MySQL.dbConnection.executeQueryRS(query2);
            while (rs2.next()) {

                String Name = null;
                try {
                    String name = rs2.getString("Name");

                } catch (SQLException e) {
                    e.printStackTrace();
                }}
                String Name= rs2.getString("Name");
                String direccion = rs2.getString("Calle");
                Cliente cliente = new Cliente(id, Name, direccion);

                return cliente;


        }

    public void crearFactura(Cliente cliente,Vendedor  vendedor, Product producto) {
        System.out.println("El cliente " + cliente.getNameCliente() + " le ha comprado a " + vendedor.getNameVendedor() + " una compra por valor de " + producto.totalPrice(producto.getPriceProduct()) + " .Los productos comprados son: " + producto.getProductos());

        /* Selector addFactura(idVendedor,Cliente.getIdCliente(),Product.getTotalPrice());*/

    }
}








