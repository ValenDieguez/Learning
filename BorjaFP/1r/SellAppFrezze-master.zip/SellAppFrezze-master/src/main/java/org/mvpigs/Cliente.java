package org.mvpigs;

import java.sql.SQLException;

public class Cliente {


    private int idCliente=0;
    private String nameCliente= null;
    private String direccionCliente=null;
   /* private Selector selector = null;*/

    public Cliente(int idCliente, String nameCliente, String direccionCliente) throws SQLException {
        this.idCliente=idCliente;
        this.nameCliente=nameCliente;
        this.direccionCliente=direccionCliente;
        /*this.selector = new Selector();*/
    }

    public  int getIdCliente() {
        return idCliente;
    }

    public String getNameCliente(){
        return this.nameCliente;
    }

    public String getDireccionCliente() {
        return this.direccionCliente;
    }

   /*public void elegirProducto() throws SQLException {
        System.out.println(this.selector.showProducts());
        /*Imput id del producto a elegir
        Product crearProducto=this.selector.createProduct(int id);
        seleccionarProducto(crearProducto);}*/





}
