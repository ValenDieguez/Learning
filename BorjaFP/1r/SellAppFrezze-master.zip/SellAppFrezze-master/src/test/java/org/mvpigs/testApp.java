package org.mvpigs;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.sql.SQLException;
import java.util.concurrent.Callable;

/**
 * Unit test for simple App.
 */
public class testApp
    extends TestCase {


    public static Test suite() {
        return new TestSuite(testApp.class);
    }

    Product producto = new Product(01521, "cosquillas", 25.00);

    public void testGetPriceProduct() {
        Product producto = new Product(01521, "cosquillas", 25.00);
        assertEquals(producto.getPriceProduct(), 25.00);
        System.out.println("price product correcta");
    }

    public void testTotalPrice() {
        Product producto = new Product(01521, "cosquillas", 25.00);
        assertEquals(producto.totalPrice(producto.getPriceProduct()), 25.00);
        System.out.println("totalPrice 1 product correcta");
        Product producto2 = new Product(01551, "pacificador", 25.00);
        assertEquals(producto2.totalPrice(producto2.getPriceProduct()), 50.00);
        System.out.println("totalPrice sumatoria product correcta");
    }

    public void testCliente() throws SQLException {
        Cliente cliente = new Cliente(00001, "Miquelet Sordera", "Ses clotes 34");
        assertEquals(cliente.getDireccionCliente(), "Ses clotes 34");
        assertEquals(cliente.getIdCliente(), 1);
        assertEquals(cliente.getNameCliente(), "Miquelet Sordera");

        System.out.println("Cliente furula");

    }

    public void testVendedor() throws SQLException {
        Vendedor vendedor = new Vendedor(00001, "Juana");
        assertEquals(vendedor.getIdVendedor(), 1);
        assertEquals(vendedor.getNameVendedor(), "Juana");

        System.out.println("Vendedor furula");
    }


    public void testFactura() throws SQLException {
        Vendedor vendedor = new Vendedor(00001, "Juana");
        Cliente cliente = new Cliente(00001, "Miquelet Sordera", "Ses clotes 34");
        Product producto = new Product(01521, "cosquillas", 25.00);

        vendedor.crearFactura(cliente,vendedor,producto);
    }
}
