
package org.mvpigs;

import java.sql.*;

public class Selector {

private Connection connect = null;
private String serverURL = "jdbc:mysql://localhost:3306/MyFirstConnection";
private Connection  connected = DriverManager.getConnection(serverURL,"root","1234");

    public Selector() throws SQLException {
    }


    public void showProducts() throws SQLException {
        System.out.Println(connect.prepareStatement("SELECT * FROM productos"));

    }
    public  Product  createProduct(int id) throws SQLException {
        String name=toString(connect.prepareStatement("SELECT Name FROM Products"));
        double price=connect.prepareStatement("SELECT Name FROM Products");

    Product product= new Product(id,name,price);

    return product;
  }

    public Vendedor createVendedor(int id) throws SQLException {

        String name = toString(connect.prepareStatement("SELECT Name FROM vendedor where idVendedor== id"));
        Vendedor vendedor= new Vendedor(id,name);

        return vendedor;
    }

    public Cliente createCliente(int id) throws SQLException {

        String name = toString(connect.prepareStatement("SELECT Name FROM Products"));
        String direccion = connect.prepareStatement("SELECT Name FROM Products");
        Cliente cliente= new Cliente(id,name,direccion);

        return cliente;
    }

    public void addFactura(int vendedor,int cliente, double totalPrice){

    }
}

select * from cliente ;