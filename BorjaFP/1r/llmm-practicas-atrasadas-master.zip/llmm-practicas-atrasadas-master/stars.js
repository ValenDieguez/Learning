var w = window.innerWidth;

var intro = document.getElementsByClassName("intro")[0];
intro.style.fontSize = w / 30 + "px";

window.addEventListener("resize", function() {
  w = window.innerWidth;
  intro.style.fontSize = w / 30 + "px";
});