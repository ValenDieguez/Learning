# 1rDual
Repository for all the projects that i do in 1rst of DAW

I'm going to introduce me. My name is Valentí, i'm from Mallorca a beautiful island in the middle of the mediterranean sea. 
Instead of a lot of people think, Mallorca is not only a touristic place. We have some of the best programers in all the world!.Thats the reason why I began to study the world of programmation.
There are a lot of reasons  to study programmation. First of all... **I'ts Awesome**, I had studied History ( Yes like the one's on the history channel but without... ![aliens](https://cdn-images-1.medium.com/max/1200/1*4h880wlY712QI226kk4Xvw.jpeg)
and do something that you can see the result of this is so exciting!
The other reasons are just based on my lifetime. I, _literally_, born with a computer on my hands. I remember me with 3 years playing with the Spectrum of my father, introducing color pencils in the cassete case ( Yeah, i broke it) and play games like ghost and goblins in a strange kind of computer _whose name never need to be pronunced_.
The first computer game called Modern that i played is the [**Age of Empires 2**](https://www.ageofempires.com/games/aoeii/). And it was the begining of all. The next thing that i remember outside of the videogames is being at the university without knowing anything of the outside world.
Finally i began to write that Readme, i think that at least it will be funny. Make something easy to read is something usefull in programming

[easy](https://giphy.com/gifs/latenightseth-boom-3o7btNa0RUYa5E7iiQ)

Subjects:
 1. LLenguatge de Marques
 2. Programació
 3. Bases de dades

First Header | Second Header
------------ | -------------
Content from cell 1 | Content from cell 2
Content in the first column | Content in the second column
