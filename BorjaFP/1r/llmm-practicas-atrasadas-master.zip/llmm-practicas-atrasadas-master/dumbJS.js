function dumb(){
	var t = document.getElementById('dumb');
	console.log(t)
	
	return t.style.backgroundImage='url("img/run.gif")';
	
}