

function changecolor(x){
	var t = document.getElementById(x).getAttribute("class");
	var y = String(t)
	console.log(y)
	var cols = document.getElementsByClassName(y);
	for(i=0; i<cols.length; i++) {
		cols[i].style.backgroundColor =    '#ffff80';
  }
  var box =     document.getElementsByClassName('caja');
  for(i=0; i<box.length; i++) {
    box[i].style.visibility =    'visible';
  }
	if (y == "bbdd") {
    return document.getElementById("insidebox").innerHTML = "INFORMACION EXTRA</br></br>Profesor :Jaume Oliver Lafont</br> Utilizacion de Bases de datos, SQL y demas aplicaciones relacionadas con el tema";
	}
	if (y === "sistemes") {
    return document.getElementById("insidebox").innerHTML = "INFORMACION EXTRA</br></br>Profesor :Ramon Jaume Vidal</br> Aprendizage de como funciona un ordenador y las partes de este. Sistemas operativos";
	}
	if (y == "programacio") {
    return document.getElementById("insidebox").innerHTML = "INFORMACION EXTRA</br></br>Profesor :David Gelpi</br> Programacion base en python y java, transformaciones en hulk en directo";
	}
	if (y == "fol") {
    return document.getElementById("insidebox").innerHTML = "INFORMACION EXTRA</br></br>Profesor :La Mari Paz to chunga</br> Enseñar bien FoL mientras adoctrinamos a los chicos a no pensar version 0.1";
	}
	if (y == "ed") {
    return document.getElementById("insidebox").innerHTML = "INFORMACION EXTRA</br></br>Profesor :David Gelpi</br> Entornos de desarrollo, como programar bien correctamente para que tus compañeros no te metan un tiro";
	}
	if (y == "llmm") {
    return document.getElementById("insidebox").innerHTML = "INFORMACION EXTRA</br></br>Profesor :Rafael Gion Muñoz</br> Html5, css, Js.. todo lo necesario para maquetar webs. Entregas de trabajos aplazadas";
	}
	if (y == "extra") {
    return document.getElementById("insidebox").innerHTML = "INFORMACION EXTRA</br></br> free time !!";
	}
}


function returncolor(x){
	var t = document.getElementById(x).getAttribute("class");;
	var y = String(t)
	var cols =     document.getElementsByClassName(y);
  for(i=0; i<cols.length; i++) {
    cols[i].style.backgroundColor =    'white';
  }
   var box =     document.getElementsByClassName('caja');
  for(i=0; i<box.length; i++) {
    box[i].style.visibility =    'hidden';
  }
}
