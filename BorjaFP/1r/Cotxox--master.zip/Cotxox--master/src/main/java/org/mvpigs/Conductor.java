package org.mvpigs;

import java.util.ArrayList;

public class Conductor {

    private String nombre = null;
    private String modelo = null;
    private String matricula= null;
    private int valoracionMedia=0;
    private ArrayList <int> valoraciones= new ArrayList<int>();
    private Boolean ocupado= false;

    public Conductor(String nombre, String modelo, String matricula,int valoracionMedia,Boolean ocupado){
        this.nombre=nombre;
        this.modelo=modelo;
        this.matricula=matricula;
        this.valoracionMedia=valoracionMedia;
        this.ocupado=ocupado;

    }


    public void setValoracion(){

    }


}
