package org.mvpigs;

import java.util.ArrayList;

public class PoolConductores {
    ArrayList<Conductor> poolConductores= new ArrayList<Conductor>();



public asignarConductor(){
    

}



}
