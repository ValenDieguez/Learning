package org.mvpigs;

public class Tarifa{

   private int costeMilla = 0;
    private int costeMinuto = 0;
    private int costeMinimo = 0;
    private int porcentajeComision = 0;

    public Tarifa( int costeMilla, int costeMinuto, int costeMinimo, int porcentajeComision){

        this.costeMilla=costeMilla;
        this.costeMinuto=costeMinuto;
        this.costeMinimo=costeMinimo;
        this.porcentajeComision=porcentajeComision;
    }

    public void getCosteDistancia(distancia){

    }
    public void getCosteTiempo(minutos){

    }
    public void getCosteTotalEsperado(carrera){

    }

}