package org.mvpigs;

public class Carrera{
    private int tiempoCarrera=0;
    private int tiempoEsperado=0;
    private int costeTotal=0;
    private String conductor=null;

    public Carrera(int tiempoCarrera, int tiempoEsperado, int costeTotal,String conductor){
        this.tiempoCarrera=tiempoCarrera;
        this.tiempoEsperado=tiempoEsperado;
        this.costeTotal=costeTotal;
        this.conductor=conductor;
    }

public void getTarjetaCredito(){
        
}

public void getOrigen(){

}

public void getDestino(){


}
public void getDistancia(){

}
public void getCosteEsperado(){


}
public void asignarConductor(PoolConductores conductores){


}
public void getCosteEsperado(){

}
public void realizarPago(pago){


}
public void recibirPropina(propina){

}
public void liberarConductor(){

}


}