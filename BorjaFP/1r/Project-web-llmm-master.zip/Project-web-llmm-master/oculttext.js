
function apear(y){
	var box =     document.getElementsByClassName('textRight');
	
  for(i=0; i<box.length; i++) {
    box[i].style.visibility =    'visible';

	
  }

  var img=	document.getElementsByClassName('imagenRight');
	 for(i=0; i<img.length; i++) {
    img[i].style.visibility =    'visible';

	
  }
  
  if (y == 1) {
    return document.getElementById("dedins").innerHTML = "Los celtas habitaron toda europa </br> no solo el norte. Prueba de </br> ello son los celtiberos. ";
	}
	if (y === 2) {
    return document.getElementById("dedins").innerHTML = "Ningun intento fue tan fuerte</br> como el protagonizado por William Wallace pero</br> hubo levantamientos practicamente hasta llegar </br>a la edad contemporania como </br>la batalla de Culloden,</br> famosa por enfrentar Espadas de</br> 2 manos a los casacas rojas.</br> Por supuesto ganaron estos ultimos";
	}
	if (y == 3) {
    return document.getElementById("dedins").innerHTML = "Realmente estos fueron unificados</br> por el mismo Temugin, quien unifico los clanes</br> a la fuerza";
	}
	if (y == 4) {
    return document.getElementById("dedins").innerHTML = "La tumba de Gengis es uno de los misterios</br> mas grandes de la historia.</br> Cuando murio se enterro en</br> un lugar secreto. Cualquiera que</br> viera su caravana era</br> asesinado. Los soldados hicieron</br> guardia hasta que la hierba crecio</br> y estos fueron muertos por otros</br> soldados, que tambien perecieron</br> a manos de otros soldados.";
	}
	if (y == 5) {
    return document.getElementById("dedins").innerHTML = "Como nos indican mas adelante</br> proceden del norte, no</br> solo de escandinavia.";
	}
	if (y == 6) {
    return document.getElementById("dedins").innerHTML = "Realmente esa era su principal</br> funcion. Gracias a ellos ciudades como</br> Novgorod progresaron y se establecio</br> una costumbre comercial en el norte que dio</br> paso al nacimiento de la Liga Hanseatica";
	}
	if (y == 7) {
    return document.getElementById("dedins").innerHTML = "Realmente esto no es asi,</br> la razon principal era que</br> al entrar en el rol europeo con sus</br> sistemas feudales, los nobles vikingos</br> no tenian la necesidad de usar</br> el pillaje, ya que tenian otros medios</br> mas faciles y menos peligrosos</br> de ganarse la vida";
	}
}






function desaparece(){
	
		var box =     document.getElementsByClassName('textRight');
	
  for(i=0; i<box.length; i++) {
    box[i].style.visibility =    'hidden';

	
  }

  var img=	document.getElementsByClassName('imagenRight');
	 for(i=0; i<img.length; i++) {
    img[i].style.visibility =    'hidden';

	
  }
	
	
	
	
	
	
	
}