function bigImg(x) {
    x.style.height = "512px";
    x.style.width = "598px";
    }

function normalImg(x) {
    x.style.height = "256px";
    x.style.width = "299px";
}