function bigImg(x) {
    x.style.height = "256px";
    x.style.width = "176px";
    }

function normalImg(x) {
    x.style.height = "128px";
    x.style.width = "88px";
}