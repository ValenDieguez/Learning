function bigImg(x) {
    x.style.height = "324px";
    x.style.width = "310px";
    }

function normalImg(x) {
    x.style.height = "162px";
    x.style.width = "155px";
}