# Wiki Age of Empires 2:
Este proyecto ha sido realizado por **Valentí Diéguez** i **Jordi Fuster**. Se abre a partir del archivo: pagInitial.html
Para la elección de este trabajo, decidimos juntar 2 temas sobre los cuales tenemos bastante control, historia por parte de Valentí y juegos por parte de los dos.
Inspirados en varias wikis de diversos juegos, decidimos crear una plataforma donde se pudiesen leer curiosidades históricas sobre el juego [Age of Empires 2](http://ageofempires.wikia.com).
A la hora de plantear el proyecto, decidimos que debia haber un menú de forma constante para poder moverse por la web, y que esta debia estar dividia en varias partes:
 - Una Pagina Inicial, como una pagina publicitaria.
 - Una página principal.
 - Una página de civilizaciones.   
 - Una página de unidades.
 - Una página de contacto.
 
Una vez planteada la idea general, nos pusimos a imaginar como debian estar estrcturadas estas páginas, y hicimos dibujos de estas para poder llegar a un acuerdo común, y planteamos una serie de funciones que queriamos en la web:
 - Poder ampliar la imagen de la unidad para verla con más detalle.
 - Ocultar parte de la información para no sobrecargar la página con texto.
 - Permitir una posible comunicación para poder corregir errores.
 - Tener un desplazamiento via menu por la web.
 - Abrir y cerrar una imagen con texto cambiante usando Js.
 - Añadir elementos como musica (solo en la pagInicial).
Para acabar, aqui destacaré las unidades y civilizaciones elegidas para este trabajo:
Civilizaciones | Unidades
------------ | -------------
Celtas | Catafracto
Mongoles | Lanzador de hachas
Vikingos | Mameluco