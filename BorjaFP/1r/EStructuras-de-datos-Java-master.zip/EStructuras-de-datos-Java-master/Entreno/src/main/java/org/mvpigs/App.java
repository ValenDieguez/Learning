package org.mvpigs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) {
        System.out.println("Hello World!");
        operaciones();
        Arrays();
        maps();
    }


    public static void operaciones(){
        String pruebas= "Semos las niñas del colegio de la Salle, 22";
        String pruebas2="Semos las niñas del colegio de la Salle, 29";

        System.out.println(pruebas.length());
        System.out.println(pruebas.charAt(4));
        System.out.println(pruebas.compareTo(pruebas2));
        System.out.println(pruebas.substring(10));
        System.out.println(pruebas.trim());
        System.out.println(pruebas.replace('a', 'A'));

    }


    public static void Arrays() {

        int[] tornado = new int[5];
        tornado[1] = 55;
        ArrayList<String> torpedo = new ArrayList<String>();

        System.out.println(tornado[0]);
        System.out.println(tornado[1]);

        for (int i = 0; i < 10; i++) {
            torpedo.add(i,"caca") ;

            System.out.println(torpedo);


        }
    }


    public static void maps(){

        Map<Integer,String> carlitos= new HashMap<Integer,String>();

        System.out.println(carlitos.size());
        System.out.println(carlitos.isEmpty());
        System.out.println(carlitos.put(1,"Madona"));
        System.out.println(carlitos.get(1));


    }

}