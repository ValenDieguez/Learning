package org.formacion.builder;

public class Persona {

    private String nombre;
    private int edad;
    private String municipio;
    private String colegio;
    private String lugarTrabajo;

    private Persona() {
    }


    public static class Builder {
        private Persona persona;

        public Builder(String nombre) {
            persona = new Persona();
            persona.nombre = nombre;
        }



        public Builder setMunicipio(String municipio) {
            persona.municipio = municipio;
            return this;
        }

        public MayorBuilder setMayor(int edad) {
            if (edad < 18) throw new IllegalArgumentException("es menor de edad " + edad);
            persona.edad = edad;
            persona.colegio = null;
            persona.lugarTrabajo = null ;
            return new MayorBuilder(persona);
        }

        public Builder setMenor(int edad, String colegio) {
            if (edad >= 18) throw new IllegalArgumentException("es mayor de edad " + edad);
            persona.edad = edad;
            persona.colegio = colegio;
            persona.lugarTrabajo = null;
            return this;
        }

        //public Builder setLugarTrabajo(String lugar){
            //persona.lugarTrabajo=lugar;
           // return this;
        //}

        public Persona build() {
            return persona;
        }

    }

    public static class MayorBuilder  {
        Persona personaAdulta= null;

        public MayorBuilder(Persona persona ) {
            personaAdulta = persona;



        }

        public MayorBuilder setLugarTrabajo(String lugar) {
            personaAdulta.lugarTrabajo=lugar;
            return this;
        }

        public Persona build() {
            return personaAdulta;
        }




    }

    public static class MenorBuilder {

    }

}
