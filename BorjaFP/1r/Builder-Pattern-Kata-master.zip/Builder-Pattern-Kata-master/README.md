Builder-Pattern-Kata
