package org.mvpigs.Bicipalma;

public class Bicicleta {

    private int id = 0;

    public Bicicleta(int id) {
        this.id = id;

    }

    public int getId() {
        return this.id;
    }

}