package org.mvpigs.Bicipalma;

public class Main {
    public static void main(String[] args) {
        System.out.println("Starting");

        Estacion estacion = new Estacion(1400, "Movistar", 60);
    }
}