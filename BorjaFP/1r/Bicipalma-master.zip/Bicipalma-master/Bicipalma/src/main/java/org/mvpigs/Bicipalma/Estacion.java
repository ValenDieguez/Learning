package org.mvpigs.Bicipalma;

import java.math.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Main Bicicleta
 *
 */
public class Estacion {

    private int id = 0;
    private String direccion = null;
    private int numAnclajes = 0;
    private Bicicleta[] anclajes = null;

    public Estacion(int id, String direccion, int numAnclajes) {
        this.id = id;
        this.direccion = direccion;
        this.numAnclajes = numAnclajes;
        this.anclajes = new Bicicleta[numAnclajes];

    }

    public void consultarEstacion() {
        System.out.println("id: " + this.id);
        System.out.println("direccion: " + this.direccion);
        System.out.println("Numero de anclajes: " + this.numAnclajes);

    }

    public void consultarAnclajes() {
        for (int i = 0; i < anclajes.length; i++) {
            if (anclajes[i] != null) {
                System.out.println(anclajes[i].getId());
            } else {
                System.out.println("There is no bike.");
            }
        }

    }

    public int anclajeslibres() {
        int anclajesVacios = 0;
        for (int i = 0; i < anclajes.length; i++) {
            if (anclajes[i] == null) {
                anclajesVacios++;
            }
        }
        return anclajesVacios;
    }

    public void anclarBicicleta(Bicicleta bicicleta) {
        for (int i = 0; i < anclajes.length; i++) {
            if (anclajes[i] != null) {
                continue;
            } else {
                anclajes[i] = bicicleta;
                mostrarAnclaje(bicicleta, i);
            }
        }

        System.out.println("There is no room for you fucking bike. n00b");
    }

    public void mostrarAnclaje(Bicicleta bicicleta, int numeroAnclaje) {
        System.out.println(" bicicleta id:" + bicicleta.getId() + " posicion: " + numeroAnclaje);

    }

    public Boolean leerTargetaUsuario(TarjetaUsuario tarjetaUsuario) {
        if (!tarjetaUsuario.getActivada()) {
            System.out.println("This card is not activated");
            return false;
        } else {
            return true;
        }
    }

    public void retirarBicicleta(TarjetaUsuario tarjetaUsuario) {
        int anclajeAleatorio = generarAnclaje();
        if (leerTargetaUsuario(tarjetaUsuario)) {
            mostrarBicicleta(anclajes[anclajeAleatorio], anclajeAleatorio);
            anclajes[anclajeAleatorio] = null;
        }
    }

    public void mostrarBicicleta(Bicicleta bicicleta, int numeroAnclaje) {
        System.out.println(
                "la bicicleta con la id: " + bicicleta.getId() + " se encuentra en el anclaje numero " + numeroAnclaje);

    }

    public int generarAnclaje() {
        int randomNumber = ThreadLocalRandom.current().nextInt();

        return Math.abs(randomNumber % anclajes.length);
    }
}