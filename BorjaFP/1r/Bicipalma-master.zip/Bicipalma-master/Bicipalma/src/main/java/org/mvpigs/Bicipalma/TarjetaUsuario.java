package org.mvpigs.Bicipalma;

public class TarjetaUsuario {

    int id = 0;
    Boolean activada = false;


    public TarjetaUsuario(int id, Boolean activada){
        this.id=id;
        this.activada=activada;
    }

    public int getTarjetaId(){
        return this.id;
    }
    public Boolean getActivada(){
        return this.activada;
    }




}