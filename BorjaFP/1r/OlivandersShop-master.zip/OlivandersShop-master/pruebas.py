linea = 'name, sellIn, quality'
print(linea.split(','))
print(len(linea.split(',')))