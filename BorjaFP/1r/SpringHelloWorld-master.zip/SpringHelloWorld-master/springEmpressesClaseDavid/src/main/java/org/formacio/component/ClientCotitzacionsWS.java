package org.formacio.component;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

//aquesta classe ha de ser detectada com un component
@Component
public class ClientCotitzacionsWS implements IntegradorCotitzacions {
    private float totalCotitzaciones= 0f;
    private int casts=0;

    public int nombreInvocacions = 0;

    public float obteMitjanaDiariaCotitzacions() {
        nombreInvocacions++; // per controls del test
        return totalCotitzaciones/casts;
    }


    @Override
    public float obteCotitzacio(String empresa) {
        switch (empresa) {
            case "cervesses.sa":
                totalCotitzaciones=totalCotitzaciones+30f;
                casts++;
                return 30f;
            case "shandies.sa":
                totalCotitzaciones=totalCotitzaciones+10f;
                casts++;
                return 10f;
            case "radler.sa":
                totalCotitzaciones=totalCotitzaciones+15f;
                casts++;
                return 15f;
            default:
                return 0f;
        }
    }
}
