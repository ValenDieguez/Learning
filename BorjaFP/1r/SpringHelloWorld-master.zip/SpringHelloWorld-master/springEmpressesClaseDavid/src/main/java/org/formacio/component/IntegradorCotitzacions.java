package org.formacio.component;

public interface IntegradorCotitzacions {

	public float obteMitjanaDiariaCotitzacions();
	
	float obteCotitzacio(String empresa);
}
