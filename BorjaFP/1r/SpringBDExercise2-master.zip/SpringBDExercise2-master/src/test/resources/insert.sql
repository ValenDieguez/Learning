delete from T_LLIBRES;
insert into T_LLIBRES (LLI_ISBN, LLI_AUTOR, LLI_TITOL, LLI_RECOMANACIO, LLI_PAGINES)
values ('123456789','John Bootify', 'Spring Boot in action', 'OBRA_MESTRE',1200);



