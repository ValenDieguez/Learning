package org.formacio.setmana2.repositori;

/**
 * Aquesta excepcio exten Exception pero no RuntimeException
 * Per tant, es del tipus checked. 
 * Recordau
 *   per defecte: checked -> commit
 * NO heu de canviar res d'aquest fitxer !
 */
public class EdatIncorrecteException extends Exception {}
