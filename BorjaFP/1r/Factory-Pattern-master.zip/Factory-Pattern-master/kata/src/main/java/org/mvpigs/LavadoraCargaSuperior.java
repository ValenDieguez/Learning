package org.mvpigs;

public class LavadoraCargaSuperior extends Lavadora {

    public LavadoraCargaSuperior() {
    	    this.tipoCarga = "superior";
    }
}
