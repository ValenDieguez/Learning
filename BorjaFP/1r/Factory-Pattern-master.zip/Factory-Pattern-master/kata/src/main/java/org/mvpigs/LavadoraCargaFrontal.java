package org.mvpigs;

public class LavadoraCargaFrontal extends Lavadora {

     public LavadoraCargaFrontal() {
    	    this.tipoCarga = "frontal";
     }
	
}
