package org.mvpigs;

public class LavadoraFrontalFactory extends LavadoraFactory {
    @Override
    protected Lavadora creaLavadora() {
        return new LavadoraCargaFrontal();
    }
}
