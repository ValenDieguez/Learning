class carta():
    def __init__(self, name,valor, description):
        self.name = name
        self.valor= valor
        self. description= description

    def __repr__(self):
        return "{0},{1},{2},{3},{4},{5}".format(self.name, self.valor, self.ataque,self.maxVida,self.efecto, self.description)

damage = 0
class esbirro(carta):

    def __init__(self, name, valor, ataque, maxVida, efecto,description):
        carta.__init__(self,name,valor,description)
        self.ataque=ataque
        self.maxVida= maxVida
        self.efecto=efecto

    def efeect(self):
        if self.efecto == 0:
            pass
        if self.efecto >0:
            pass

    def atacar(self):
        damage = self.ataque
        return damage

    def recibirDaño(self, damage):
        if self.maxVida > damage:
            vida = self.maxVida - damage
            return vida
        if self.maxVida <= damage:
            return "monster is destroyed"

if __name__== "__main__":
    Doomguard = esbirro("doomguard",5, 5, 7, "battlecry: descarta dos cartas","Summoning a doomguard is risky. Someone is going to die.")
    print (Doomguard)
    prueba = Doomguard.recibirDaño(1)
    print(prueba)
    print(Doomguard.atacar())
    print(Doomguard.recibirDaño(9))
