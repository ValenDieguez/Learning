effectDictionary= { 1: "heal"
}

def heal(ammountHealed):
    if vida