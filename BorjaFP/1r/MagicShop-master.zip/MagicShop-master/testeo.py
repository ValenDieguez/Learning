class Item():
    """

    """
    def __init__(self, name, sellIn, quality):
        self.name = name
        self.sellIn = sellIn
        self.quality = quality

    def __repr__(self):
        return "{0},{1},{2}".format(self.name, self.sellIn,self.quality)


class Interfaz():
    """

    """
    def updateQuality(self):
        pass


class normalItem(Item, Interfaz):
    """

    """
    def __init__(self, name, sellIn, quality):
        Item.__init__(self, name, sellIn, quality)

    def updateQuality(self):
        self.quality += 1
        return self.quality


class agedBrie(normalItem):
    """

    """
    def updateQuality(self):
        self.quality += 2
        return self.quality


if __name__== "__main__":
    item = agedBrie("doomguard", 7, 5)
    print (item)
    item.updateQuality()
    print (item)