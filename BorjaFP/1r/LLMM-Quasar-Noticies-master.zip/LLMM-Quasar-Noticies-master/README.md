# LLMM-Quasar-Noticies
LLMM Treball -> Quasar and VUE

Maquetacio

La idea era realitzar una parodia de les red socials, concretament Facebook, Intent mantenir el mateix estil grafic ( blau i blanc) y el mateix patro de disseny.

Per aixo, hem utilitzat un tema que me du perseguint tot l'any, l'exces de greix i la seva acceptacio.

Cada una de les noticies va dins una card que conte una imatge, un titol una breu descripcio i un boto que obre un modal que conte mes informació.

Intentarem que amb el json sautogenerin mes noticies de manera infinita i/o un boto que introduesqui les noticies.

Tambe intentarem assolir els altres objectius i mostrarlo lo mes bonic possible


