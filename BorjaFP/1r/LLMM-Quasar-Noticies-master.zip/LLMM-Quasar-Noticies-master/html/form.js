var optionArray = ["name", "phone", "email", "company", "city", "message"];
var optionArrayEsp = ["Nombre", "Telefono", "Correo", "Compañia", "Ciudad", "Mensaje"];
var optionArrayEng = ["Name", "Phone", "Email", "Company", "City", "Message"];
var atributeArray = [];
var badgeArray = [];
var newsletter = false;
var divContainer = document.getElementById("container");
var contact = {
    project: "inmobelt"
};

//Pinta el formulario
function formPaint() {
    var arrayTexts = [];
    if (window.navigator.language == 'es-ES') {
        arrayTexts = optionArrayEsp;
    } else {
        arrayTexts = optionArrayEng;
    }
    apiInterestCall();
    var formTitle = document.createElement("h3");
    formTitle.setAttribute("id", "htmlTitle");
    formTitle.innerHTML = "Formulario de inscripción";
    divContainer.appendChild(formTitle);
    var form = document.createElement("form");
    form.setAttribute("class", "form");
    form.setAttribute("id", "form");
    // form.setAttribute("novalidate");
    divContainer.appendChild(form);
    var divButton = document.createElement("div");
    divButton.setAttribute("id", "button");
    divContainer.appendChild(divButton);
    var divSubscribe = document.createElement("div");
    divSubscribe.setAttribute("id", "subscribe");
    divContainer.appendChild(divSubscribe);
    divContainer.setAttribute("class", "container");
    var project = document.getElementById("script").getAttribute("data-project");
    contact.project = project;
    var subscribe = document.getElementById("subscribe");
    var buttonId = document.getElementById("button");

    var divGeneral = document.createElement("div");
    divGeneral.setAttribute("class", "row");
    form.appendChild(divGeneral);
    for (option in optionArray) {
        var div = document.createElement("div");
        div.setAttribute("class", "col-md-6");
        var title = document.createElement("h6");
        title.innerHTML = arrayTexts[option] + "<br>";
        div.appendChild(title);
        if (optionArray[option] == "message") {
            var input = document.createElement("textarea");
            input.setAttribute("rows", 7);
            input.setAttribute("cols", 100);
            div.setAttribute("class", "col-md-8 mt-1");
        } else {
            var input = document.createElement("input");
            div.setAttribute("class", "col-md-6 mt-1");
        }
        input.type = "text";
        input.className = "css-class-name";
        input.setAttribute("id", "input" + optionArray[option]);
        input.setAttribute("class", "form-control");
        input.setAttribute("placeholder", arrayTexts[option]);
        div.appendChild(input);
        divGeneral.appendChild(div);
    }
    var checkbox = document.createElement("input");
    checkbox.setAttribute("type", "checkbox");
    checkbox.setAttribute("id", "checkbox");
    checkbox.setAttribute("value", "newsletter");
    checkbox.setAttribute("class", "m-1");
    // checkbox.setAttribute("class","form-check-input");
    checkbox.setAttribute("onclick", "showInterests()");
    subscribe.appendChild(checkbox);
    var label = document.createElement("label");
    label.setAttribute("for", "checkbox");
    label.innerHTML = "¿quieres recibir nuestros newsletters?";
    subscribe.appendChild(label);

    var button = document.createElement("button");
    button.setAttribute("onclick", "readForm()");
    button.setAttribute("class", "btn btn-primary m-3");
    button.innerHTML = "send";
    buttonId.appendChild(button);
}

// al pulsar el boton enviar, lee el formulario y comprueba que las respuestas sean correctas
function readForm() {
    var send = true;
    for (option in optionArray) {
        var name = optionArray[option];
        var statement = "input" + name;
        var value = document.getElementById(statement).value;
        if (optionArray[option] == "email") {
            if (isEmail(value)) {
                paintWhite(statement, name, value);
            } else {
                paintRed(statement);
                send = false;
            }
        }
        else if (optionArray[option] == "name" || optionArray[option] == "message") {
            if (value.length >= 3) {
                paintWhite(statement, name, value)
            } else {
                paintRed(statement);
                send = false;
            }
        }
        else if (optionArray[option] == "phone") {
            if (isNumber(value)) {
                paintWhite(statement, name, value);
            } else {
                paintRed(statement);
            }
        } else {
            contact[name] = value;
        }
    }
    if (newsletter) {
        var interestsValue = [];
        for (interest of badgeArray) {
            interestsValue.push(interest.id);
        }
        contact["interests"] = interestsValue;
    }
    if (send) {
        apiSend();
    }
}

//recupera los intereses del projecto dado
function apiInterestCall() {
    var basePath = document.getElementById("script").getAttribute("data-basepath");
    var url = basePath + "/subscription/interests?project=" + contact.project;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            atributeArray = JSON.parse(xhttp.response).areas;
            return atributeArray;
        }
    };
    this.atributeArray = atributeArray;
    xhttp.open("GET", url, true);
    xhttp.send();
}

//se encarga de enviar los resultados del formulario al API
function apiSend() {
    var basePath = document.getElementById("script").getAttribute("data-basepath");
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            formMessage("welcome");
        } else if (this.readyState == 4 && this.status != 200) {
            formMessage("error");
        }
    };
    xhttp.open("POST", basePath + "/contact", true);
    xhttp.setRequestHeader('Content-Type', 'application/json');
    xhttp.send(JSON.stringify(contact));
}

//crea o destruye el div que contiene los intereses, dependiendo de  si el checkbox esta aceptado
function showInterests() {
    var subscribe = document.getElementById("subscribe");
    if (newsletter == false) {
        newsletter = true;
        var div = document.createElement("div");
        div.setAttribute("style", "margin: 2%;");
        div.setAttribute("class", "row");
        div.setAttribute("id","selectContainer");
        var select = document.createElement("select");
        select.setAttribute("id", "atributes");
        select.setAttribute("multiple", true);
        select.setAttribute("name", "atributes");
        select.setAttribute("class", "col-md-3 p-0 m-0");
        var atributeContainer = document.createElement("optgroup");
        atributeContainer.setAttribute("class", "list-group p-0 m-0");
        select.appendChild(atributeContainer);
        for (var attribute of atributeArray) {
            var attributeOption = document.createElement("option");
            attributeOption.innerHTML = attribute.text;
            attributeOption.setAttribute("value", attribute.id);
            attributeOption.setAttribute("id", attribute.text);
            attributeOption.setAttribute("class", "list-group-item p-3");
            attributeOption.setAttribute("onclick", 'printBadge(' + atributeArray.indexOf(attribute) + ')');
            atributeContainer.appendChild(attributeOption);
        }
        var divBadge = document.createElement("div");
        divBadge.setAttribute("id", "divBadge");
        divBadge.setAttribute("class", "col-md-6");
        div.appendChild(select);
        div.appendChild(divBadge);
        subscribe.appendChild(div);
    } else {
        newsletter = false;
        var select = document.getElementById("atributes");
        var badge = document.getElementById("divBadge");
        var div = document.getElementById("selectContainer");
        badgeArray = [];
        select.parentNode.removeChild(select);
        badge.parentNode.removeChild(badge);
        div.parentNode.removeChild(div);
    }
}

//si viene alguna variable por path, esta funcion la recoge

// function getQueryVariable(variable) {
//     var query = window.location.search.substring(1);
//     var vars = query.split("&");
//     for (var i = 0; i < vars.length; i++) {
//         var pair = vars[i].split("=");
//         if (pair[0] == variable) {
//             return pair[1];
//         }
//     }
//     return false;
// }

//comprueba si el parametro es un email
function isEmail(email) {
    let expr = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return expr.test(email);
}

//comprueba si el parametro es un numero
function isNumber(number) {
    return Number.isInteger(Number.parseInt(number)) && number.length > 8 && number.length < 13;
}

//una vez este enviado el form, pinta en pantalla un mensaje
function formMessage(type) {
    var buttonId = document.getElementById("button");
    var subscribe = document.getElementById("subscribe");
    var form = document.getElementById("form");
    document.getElementById('container').removeChild(form);
    document.getElementById('container').removeChild(buttonId);
    document.getElementById('container').removeChild(subscribe);
    document.getElementById('container').removeChild(document.getElementById("htmlTitle"));
    if (type == "welcome") {
        var title = document.createElement("h2");
        title.innerHTML = "Welcome to Arteco Apps" + "<br>";
        var div = document.createElement("div");
        div.setAttribute("class", "col-md-6");
        div.appendChild(title);
        div.setAttribute("class", "col-md-6");
        var text = document.createElement("p");
        text.innerHTML = "Your subscription is successfull" + "<br>";
        div.appendChild(text);
        divContainer.appendChild(div);
    } else {
        var title = document.createElement("h2");
        title.innerHTML = "An error has Ocurred" + "<br>";
        var div = document.createElement("div");
        div.setAttribute("class", "col-md-6");
        div.appendChild(title);
        div.setAttribute("class", "col-md-6");
        var text = document.createElement("p");
        text.innerHTML = "Please try your subscription again!" + "<br>";
        div.appendChild(text);
        var button = document.createElement("button");
        button.setAttribute("onclick", "readForm()");
        button.innerHTML = "try again";
        div.appendChild(button);
        divContainer.appendChild(div);
    }
}

// pinta los badges de los intereses
function printBadge(id) {
    var badgeObject = atributeArray[id];
    var atribute = document.getElementById(badgeObject.text);
    var found = false;
    var div = document.getElementById("divBadge");
    var badge = document.createElement("span");
    for (var badgeText of badgeArray) {
        if (badgeText.text == badgeObject.text) {
            found = true;
            atribute.setAttribute("class", "bg-white text-black p-3");
            badgeArray.splice(badgeArray.indexOf(badgeObject),1);
            var eliminateBadge = document.getElementById(badgeObject.id);
            div.removeChild(eliminateBadge);
        }
    }
    if (!found) {
        badgeArray.push(badgeObject);
        atribute.setAttribute("class", "bg-primary text-white p-3");
        badge.setAttribute("class", "badge badge-primary");
        badge.setAttribute("id", badgeObject.id);
        badge.setAttribute("onclick", 'printBadge(' + id + ')');
        badge.setAttribute("class", "m-1 p-1 bg-primary text-white rounded");
        badge.innerHTML = badgeObject.text;
        div.appendChild(badge);
    }
}

//pinta el borde de blanco, si el input es correcto
function paintWhite(statement, name, value) {
    document.getElementById(statement).style.borderColor = "#ced4da";
    contact[name] = value;
}

//pinta el borde de rojo, si el input es incorrecto
function paintRed(statement) {
    document.getElementById(statement).style.borderColor = "red";
}

formPaint();