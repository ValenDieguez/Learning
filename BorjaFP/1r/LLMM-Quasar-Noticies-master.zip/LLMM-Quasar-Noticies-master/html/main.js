var countNoticia = 0;
var totalNoticias = 4;
var firstTimeShowMore = false;

// Lee json
$.getJSON('https://raw.githubusercontent.com/ValenDieguez/LLMM-Quasar-Noticies/master/html/Noticias.json', function (data) {
    $.each(data.noticia, function (i, f) {
        totalNoticias++;
    });
});
//function data(){ $.getJSON('https://raw.githubusercontent.com/ValenDieguez/LLMM-Quasar-Noticies/master/html/Noticias.json', function (data) {})}
var caracola = $.getJSON('https://raw.githubusercontent.com/ValenDieguez/LLMM-Quasar-Noticies/master/html/Noticias.json', function (data) {})

function data(aixo){

}

function addNoticia() {

    var contador = 4
    $.getJSON("Noticias.json", function(data){
        $.each(data, function(key, val){
            $('#infinite').append('<div class="container">'+
            '<div class="card" style="width: 30rem; margin-left:30%; margin-top:2%; ">'+
                '<img class="card-img-top" src="' + val['image'] + '"alt="Card image cap">'+
                '<div class="card-body">'+
                    '<h5 class="card-title">' + val['Title'] + '</h5>'+
                    '<p class="card-text">' + val['text'] + '</p>'+
                    '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#noticia' + contador +'">Comer Mas</button>'+
                '</div>'+
            '</div>'+
        '</div>');
        
        if (firstTimeShowMore == false) {
            $('#modalsJs').append('<div class="modal fade" id="noticia' + contador + '" tabindex="-1" role="dialog" aria-labelledby="ModalLabel3" aria-hidden="true">'+
            '<div class="modal-dialog" role="document">'+
            '<div class="modal-content">'+
            '<div class="modal-header">'+
            '<h5 class="modal-title" id="ModalLabel3">' + val['Title'] + '</h5>'+
            '<button type="button" class="close" data-dismiss="modal" aria-label="Close">'+
            '<span aria-hidden="true">&times;</span>'+
            '</button>'+
            '</div>'+
            '<div class="modal-body">'+
            '<a href="' + val['link'] + '" style="button">escuchala!</a>'+
            '<p>'+ val['largo'] +
            '</p>'+
            '</div>'+
            '<div class="modal-footer">'+
            '<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>'+
            '</div>'+
            '</div>'+
            '</div>'+
            '</div>');
        }
        contador = contador + 1;
        });
        firstTimeShowMore = true;
    });
}


function mostrar(des) {
    $(".noticiaCompleta", des).dialog({
        minHeight: $(window).height() - 500,
        minWidth: $(window).width() - 800,
        show: {
            effect: "blind",
            duration: 500
        },
        hide: 'drop',
    });
    $(".noticiaCompleta", des).dialog('open');

}

function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}

$(document).ready(function () {
var a =true;
if (a == true){
    /* Every time the window is scrolled ... */
    $(window).scroll(function () {/*var contador = 4
                                      $.getJSON("News2.json", function(data){
                                          $.each(data, function(key, val){
                                              $('#infinite').append('<div class="container">'+
                                              '<div class="card" style="width: 30rem; margin-left:30%; margin-top:2%; ">'+
                                                  '<img class="card-img-top" src="' + val['image'] + '"alt="Card image cap">'+
                                                  '<div class="card-body">'+
                                                      '<h5 class="card-title">' + val['Title'] + '</h5>'+
                                                      '<p class="card-text">' + val['text'] + '</p>'+
                                                      '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#noticia' + contador +'">Comer Mas</button>'+
                                                  '</div>'+
                                              '</div>'+
                                          '</div>');

                                          if (firstTimeShowMore == false) {
                                              $('#modalsJs').append('<div class="modal fade" id="noticia' + contador + '" tabindex="-1" role="dialog" aria-labelledby="ModalLabel3" aria-hidden="true">'+
                                              '<div class="modal-dialog" role="document">'+
                                              '<div class="modal-content">'+
                                              '<div class="modal-header">'+
                                              '<h5 class="modal-title" id="ModalLabel3">' + val['Title'] + '</h5>'+
                                              '<button type="button" class="close" data-dismiss="modal" aria-label="Close">'+
                                              '<span aria-hidden="true">&times;</span>'+
                                              '</button>'+
                                              '</div>'+
                                              '<div class="modal-body">'+
                                              '<a href="' + val['link'] + '" style="button">escuchala!</a>'+
                                              '<p>'+ val['largo'] +
                                              '</p>'+
                                              '</div>'+
                                              '<div class="modal-footer">'+
                                              '<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>'+
                                              '</div>'+
                                              '</div>'+
                                              '</div>'+
                                              '</div>');
                                          }
                                          contador = contador + 1;
                                          });
                                          firstTimeShowMore = true;
                                      });
                                  }

)*/}); }})