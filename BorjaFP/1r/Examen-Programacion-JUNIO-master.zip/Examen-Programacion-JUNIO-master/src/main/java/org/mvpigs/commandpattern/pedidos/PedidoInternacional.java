package org.mvpigs.commandpattern.pedidos;

import org.mvpigs.commandpattern.interfaces.Pedido;

import java.util.UUID;

public class PedidoInternacional implements Pedido {
    private String destinoVar;
    private int pesoVar;
    private UUID id;

    public PedidoInternacional(String destino, int peso) {
        this.destinoVar = destino;
        this.pesoVar = peso;

    }

    @Override
    public int peso() {
        return getPesoVar();
    }

    @Override
    public String destino() {
        return getDestinoVar();
    }

    public String getDestinoVar() {
        return destinoVar;
    }

    public UUID getId() {
        if (this.id == null) {
            this.id = UUID.randomUUID();
            return this.id;
        } else {
            return this.id;
        }

    }
    public int getPesoVar() {
        return pesoVar;
    }

}
