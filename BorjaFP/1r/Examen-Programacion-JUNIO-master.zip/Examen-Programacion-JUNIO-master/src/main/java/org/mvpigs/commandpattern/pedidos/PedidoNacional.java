package org.mvpigs.commandpattern.pedidos;

import org.mvpigs.commandpattern.interfaces.Pedido;

import java.util.UUID;

public class PedidoNacional implements Pedido {
    private String destino;
    private int peso;
    private UUID id;

    public PedidoNacional(String destino, int peso) {
        this.destino = destino;
        this.peso = peso;
    }

    @Override
    public int peso() {
        return this.peso;
    }

    @Override
    public String destino() {
        return this.destino;
    }

    public UUID getId() {
        if (this.id == null) {
            this.id = UUID.randomUUID();
            return this.id;
        } else {
            return this.id;
        }
    }
}
