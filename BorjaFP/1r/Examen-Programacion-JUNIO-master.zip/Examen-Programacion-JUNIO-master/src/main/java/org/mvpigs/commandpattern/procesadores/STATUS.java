package org.mvpigs.commandpattern.procesadores;

public enum STATUS {
    ACEPTADO {},
    RECHAZADO {}
}
