package org.mvpigs.commandpattern.pedidos;

import org.mvpigs.commandpattern.interfaces.PedidoPeligroso;

import java.util.UUID;


public class PedidoPeligrosoOrden implements PedidoPeligroso {
    private String destino;
    private String instrucciones;
    private int peso;
    private UUID id ;

    public PedidoPeligrosoOrden(String destino, String instrucciones) {
        this.destino=destino;
        this.instrucciones = instrucciones;
    }

    @Override
    public String instrucciones() {
        return getInstrucciones();
    }

    @Override
    public int peso() {
        return getPeso();
    }

    @Override
    public String destino() {
        return getDestino();
    }

    public String getDestino() {
        return destino;
    }

    public String getInstrucciones() {
        return instrucciones;
    }

    public int getPeso() {
        return peso;
    }

    public UUID getId() {
        if (this.id == null) {
            this.id = UUID.randomUUID();
            return this.id;
        } else {
            return this.id;
        }
    }
}
