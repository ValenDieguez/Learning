package org.mvpigs.commandpattern.tratamientos;

import org.mvpigs.commandpattern.interfaces.TratamientoPedido;
import org.mvpigs.commandpattern.pedidos.PedidoMultiple;

public class TratamientoPedidoMultiple implements TratamientoPedido {
    private int pesoTotal;
    private int bultos;
    private int numPedidosIndividuales;
    private PedidoMultiple pedido;

    public TratamientoPedidoMultiple(PedidoMultiple pedido) {
        this.pedido = pedido;
        this.pesoTotal = pedido.getPesoTotal();
        this.bultos = pedido.size();
    }

    @Override
    public boolean tratar() {


        if (this.pesoTotal > 0 && this.bultos == this.pedido.size()) {
            return true;
        } else {
            return false;
        }
    }

    public int calcularTotalBultos() {
        return this.pedido.size();
    }

    public int getNumBultos() {
        return this.bultos;
    }

    public int calcularPesoTotal() {
        return pedido.getPesoTotal();
    }

    public int getPesoTotal() {
        return this.pesoTotal;
    }
}

