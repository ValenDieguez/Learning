package org.mvpigs.commandpattern.procesadores;

import org.mvpigs.commandpattern.interfaces.Pedido;
import org.mvpigs.commandpattern.interfaces.Procesador;
import org.mvpigs.commandpattern.interfaces.TratamientoPedido;
import org.mvpigs.commandpattern.tratamientos.TratamientoPedidoInternacional;

public class Oficina implements Procesador {


    @Override
    public boolean procesa(TratamientoPedido pedido) {

        if (pedido.tratar()) {
            return true;
        } else {
            return false;
        }
    }

    public String printarStatus(Boolean esCorrecto, Pedido pedido) {
        if (esCorrecto) {
            String frase = pedido.destino() + " " + STATUS.ACEPTADO;
            return frase;
        } else {
            String frase = pedido.destino() + " " + STATUS.RECHAZADO;
            return frase;
        }
    }
}
