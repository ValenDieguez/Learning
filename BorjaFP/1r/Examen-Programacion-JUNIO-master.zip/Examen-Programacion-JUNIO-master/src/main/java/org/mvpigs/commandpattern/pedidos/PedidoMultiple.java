package org.mvpigs.commandpattern.pedidos;

import org.mvpigs.commandpattern.interfaces.Pedido;

import java.util.HashMap;

public class PedidoMultiple implements Pedido {
    private int peso;
    private String destino;
    private HashMap<String, Integer> pedidos = new HashMap<>();
    private int pesoTotal;

    public PedidoMultiple() {

    }

    @Override
    public int peso() {
        return this.peso;
    }

    @Override
    public String destino() {
        return this.destino;
    }

    public void insertPedido(Pedido pedido) {
        this.peso = pedido.peso();
        this.destino = pedido.destino();
        pedidos.put(this.destino, this.peso);
        ;
    }

    public int size() {
        return pedidos.size();
    }

    public HashMap<String, Integer> getPedidos() {
        return pedidos;
    }

    public int getPesoTotal() {
        for (int i : this.getPedidos().values()
                ) {
            this.pesoTotal = this.pesoTotal + i;
        }
        return this.pesoTotal;
    }

}
