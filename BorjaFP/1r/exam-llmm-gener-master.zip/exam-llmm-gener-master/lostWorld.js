function addParagraf(a) {
	var x=0
	var parrafos = document.getElementsByTagName("p");
	var f = parrafos.length
	var y = f+1
	console.log(f)
		
  
	return document.getElementById(1).innerHTML ="<p>hay "+f+" parrafos y con este hay "+y+" parrafos</p>";
	
	
}