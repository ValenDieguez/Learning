# exam-llmm-gener
First exam of llmm
