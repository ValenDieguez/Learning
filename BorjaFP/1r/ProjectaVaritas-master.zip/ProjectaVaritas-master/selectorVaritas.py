from diccionarioVaritas import cualidad
from generoVaritas import genero
import habilidadVaritas
# Esta es la funcion principal, que coge los elementos de las demas
# funciones y los unifica


def selector(tipo, skill, poder):
    fuerza = habilidadVaritas.habilidad(poder)
    if fuerza is True:
        sexo = genero(tipo)
        habilidad = cualidad[skill]

        return "Tu varita es de " + sexo + " con " + habilidad
    else:
        return fuerza
