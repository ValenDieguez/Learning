# esta nos ayuda a elegir el tipo de madera( se puede, debe mejorar)
def genero(sexo):
    if sexo == "Varon":
        return "Madera de Chopo Neozenlandes"
    elif sexo == "Mujer":
        return "Madera de Abeto congoleño"
    else:
        return "Madera de ciruelo vulgar (por gracios@)"
