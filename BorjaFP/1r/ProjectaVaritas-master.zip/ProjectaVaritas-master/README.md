# ProjectaVaritas
Pruebas para un programita para poner a prueba lo aprendido estos primeros meses. 
