#esta funcion sera la que similura los imputs de los usuarios
import testVaritas
import selectorVaritas


def entrada(x):
    empezar = input("¿quiere empezar?(R= si o no): ")
    if empezar == "si":
        respuesta = selectorVaritas.selector(testVaritas.tipo(1),testVaritas.skill(1),testVaritas.poder(1))
        return respuesta
    elif empezar == "no":
        return "Hasta otra!"
    else:
        print(" se ha equivocado, vuelva a intentarlo")
        return entrada(1)


print (entrada(1))
