# Aqui pondremos todas las preguntas para recoger la informacion


def tipo(x):
    tipo = input("¿Eres Varon o Mujer? ( R= Varon o Mujer): ")
    return tipo


def skill(x):
    skill = input(
        "Indica tu principal cualidad (R= valiente, inteligente, compasivo, persuaivo o dureza): ")
    return skill


def poder(x):
    poder = int(input("dia del mes en que naciste: ")) * 2
    return poder
