# diccionario de cualidades de los magos
cualidad = {"valiente": "pelo de unicornio", "inteligente": "berruga de gnomo",
            "persuasivo": "lengua de sirena", "compasivo": "lagrima de ekidna", "dureza": "escama de gorgona"}
