# Esta funcion sirve  para relacionar el poder del mago, ademas nos hace
# un poco de cortafuegos


def habilidad(num):
    isReal = False
    if num <= 0:
        return "Esto no es para ti, sangre sucia"
    elif num > 0 and num <= 90:
        return isReal is False
    elif num > 90 and num <= 100:
        return "La varita de Sauco es tuya"
    else:
        return "La fuerza es poderosa en ti pequeño padawan, pero no necesitas una varita"
