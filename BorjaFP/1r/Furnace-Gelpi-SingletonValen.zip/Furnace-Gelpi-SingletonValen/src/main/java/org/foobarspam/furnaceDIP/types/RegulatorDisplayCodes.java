package org.foobarspam.furnaceDIP.types;

public enum RegulatorDisplayCodes {
	ON, OFF, HEATING, WAITING;
}
