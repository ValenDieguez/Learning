package org.foobarspam.furnaceDIP.types;

public class RoomTemperature {

    private double temperature = 15;

    private static RoomTemperature temperatura = new RoomTemperature();

    private RoomTemperature() {
    }

    public static RoomTemperature getInstance() {
        return temperatura;
    }

    public double getTemperature() {
        return this.temperature;
    }

    public void incrementTemperature(double increment) {
        this.temperature += increment;
    }

}
